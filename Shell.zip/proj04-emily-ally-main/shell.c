/*****
* Project 04: Shell
* COSC 208, Introduction to Computer Systems, Fall 2020
*****/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/types.h>
#include <stdbool.h>

#define PROMPT "shell> "
#define MAX_BACKGROUND 50

/*
 * Break input string into an array of strings.
 * @param input the string to tokenize
 * @param delimiters the characters that delimite tokens
 * @return the array of strings with the last element of the array set to NULL
 */
char** tokenize(const char *input, const char *delimiters) {
    char *token = NULL;

    // make a copy of the input string, because strtok
    // likes to mangle strings.  
    char *input_copy = strdup(input);

    // find out exactly how many tokens we have
    int count = 0;
    for (token = strtok(input_copy, delimiters); token; 
            token = strtok(NULL, delimiters)) {
        count++ ;
    }
    free(input_copy);

    input_copy = strdup(input);

    // allocate the array of char *'s, with one additional
    char **array = (char **)malloc(sizeof(char *)*(count+1));
    int i = 0;
    for (token = strtok(input_copy, delimiters); token;
            token = strtok(NULL, delimiters)) {
        array[i] = strdup(token);
        i++;
    }
    array[i] = NULL;
    free(input_copy);
    //free(token);
    return array;
}

/*
 * Free all memory used to store an array of tokens.
 * @param tokens the array of tokens to free
 */
void free_tokens(char **tokens) {
    int i = 0;
    while (tokens[i] != NULL) {
        free(tokens[i]); // free each string
        i++;
    }
    free(tokens); // then free the array
}

/*
* Create and begin execute of a background process
* Add the pid of the background process to the list of background processes currently running
*/
void add_pid(__pid_t arr[], char *command[]) {
    //get next available spot in the array
    int index = 0;
    while(arr[index] != '\0') {
        index++;
    }

    int command_index = 0;
    while(command[command_index] != NULL) {
        command_index++;
    }
    //create a copy of the command arry 
    char *command_copy[command_index+1];
    for(int i = 0; i < command_index; i++) {
        command_copy[i] = command[i];
    }
    command_copy[command_index-1] = NULL;

    __pid_t background_pid = fork();
    if (background_pid == 0) { 
        //check if there is an error replacing current process with process to be executed
        if (execv(command[0], command_copy) < 0) {
            fprintf(stderr, "execv failed: %s\n", strerror(errno));
            free_tokens(command);
            exit(1);
        }
    }
    //if a parent process add to the background process
    else{
        arr[index] = background_pid;
        arr[index+1] = '\0';  
    }
}


//Remove the specified pid from list of background processes
void remove_pid(__pid_t arr[], __pid_t pid_num){
    int index = 0;
    //get the index that has the pid to remove
    while(arr[index] != pid_num) { 
        index++;
    }
    //shift everything one spot to the left to remove the specified pid
    while(arr[index] != '\0') { 
        arr[index] = arr[index+1];
        index++;
    }
}

//scan the list at the end of the main function
//see if any background processes have finished running
//if they are finished then print the exit message
//check for errors with waitpid
void scan_list(__pid_t arr[]){
    int i = 0;
    int status;
    while (arr[i] != '\0'){
        if (waitpid(arr[i], &status, WNOHANG) > 0) {
            printf("%d finished with exit code %d\n", arr[i], status);  
            remove_pid(arr, arr[i]);
        } 
        //check if error occured when calling waitpid
        else if (waitpid(arr[i], &status, WNOHANG) == -1) {
            printf("Error with waitpid...\n");
            i++;
        } else {
            i++;
        }
    }
}

// Get the last character of the input to see if it should be executed as a background process
bool get_last_char(char **command) {
    int index = 0;
    while(command[index] != NULL) {
        if((strcmp(command[index], "&") == 0) && (command[index+1] == NULL)) { 
            return true;
        }
        index++;
    }
    //return false if it is not a background procees return true if it is
    return false;
}

//print to the screen the list of jobs that are currently running
void list_jobs(__pid_t procs[]) {
    if(procs[0] == '\0') {
        printf("No Background Processes Currently Running\n");
    } else { //iterate through the array of pids 
        printf("Process currently active: ");
        int index = 0;
        while (procs[index] != '\0') {
            if(procs[index+1] == '\0') {
                printf("%d\n", procs[index]);
            } else {
                printf("%d, ", procs[index]); //print them without a new line
            }
            index++;
        }
    }
}

//Check if the requested pid is running
//If not running print out a message telling the user that it's not running
void kill_process(int kill_pid, __pid_t background_proc[]) {
    bool running = false;
    int index = 0;
    while(background_proc[index] != '\0') {
        if(background_proc[index] == kill_pid) {
            running = true;
            break;
        }
        index++;        
    }
    //if the process with given pid is running remove from the background processes
    //then kill the process
    if(running) {
        remove_pid(background_proc, kill_pid);
        kill(kill_pid, SIGKILL);
    } else {
        printf("Child process with pid %d is not running\n", kill_pid); //prints a different pid than I what I entered
    }
    
}

int main(int argc, char **argv) {
    // main loop for the shell
    printf("%s", PROMPT);
    fflush(stdout);  // Display the prompt immediately
    char buffer[1024];
    //create empty array to be contained with background processes
    __pid_t background_proc[MAX_BACKGROUND];
    background_proc[0] = '\0';
    while (fgets(buffer, 1024, stdin) != NULL) {
        char **command = tokenize(buffer, " \t\n");
        //ignore if the input is a space or seris of whitespaces
        if (command[0] != NULL) {
            bool background = get_last_char(command);
            if(background) {
                add_pid(background_proc, command);
            } else {
                //check for built in commands
                if(strcmp(command[0], "exit") == 0 && command[1] == NULL) { //check for built in command exit
                    free_tokens(command);
                    exit(1);
                } else if (strcmp(command[0], "jobs") == 0 && command[1] == NULL) { //check for built in command jobs
                    list_jobs(background_proc);
                } else if (strcmp(command[0], "kill") == 0 && command[2] == NULL) { // check for built in command kill
                    kill_process(atoi(command[1]), background_proc);
                } else { //if it is a non-built in and not a backgrond process
                    __pid_t pid = fork();
                    //if the child process
                    if (pid == 0) {
                        if (execv(command[0], command) < 0) {
                            fprintf(stderr, "execv failed: %s\n", strerror(errno));
                            free_tokens(command);
                            exit(1);
                        }
                    } else { //make the parent proccess wait for the child proccess to finish executing
                        waitpid(pid, NULL, 0);
                    }
                }
            }
        }
        //free the space on the heap from the command
        free_tokens(command);
        scan_list(background_proc);
        printf("%s", PROMPT);
        fflush(stdout);  // Display the prompt immediately
    }
    return EXIT_SUCCESS;
}
