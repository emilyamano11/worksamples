import java.util.*;

/**
 * Colgate University COSC 290 Labs
 * Version 0.1,  2017
 *
 * @author Michael Hay
 */
public class BoardCounting {


    /**
     * DLN 9.100
     * @return number of leaves in game tree (when you play til board is completely filled in)
     */
    public static int countFilledIn() {
        return countFilledIn(new Board());
    }

    /**
     * Variation on DLN 9.100
     * @param b current board
     * @return number of leaves in game subtree whose root is board b
     */
    public static int countFilledIn(Board b) {
      int rows = b.size();
      if (b.isFull())  //Fix this line!
        return 1;
      int total = 0;
      Board.Mark current = b.nextPlayer();
      for (int row = 0; row < rows; row++){
        for (int col = 0; col < rows; col++){
          if (b.isOpen(row, col)){
            Board temp = b.copy();
            temp.placeMark(row, col, current);
            total += countFilledIn(temp);  
          }
        }
      }
      return total;
    }

    /**
     * DLN 9.101
     * @return number of unique leaves in game tree (when you play til board is completely filled in)
     */
    public static int countDistinctFilledIn() {
        return countDistinctFilledIn(new Board());
    }

    /**
     * Variation on DLN 9.101
     * @param b current board
     * @return number of unique leaves in game subtree whose root is board b
     */
    public static int countDistinctFilledIn(Board b) {
        return distinctFilledInHelper(b).size();
    }
    
    
    //Recursive helper function for countDistinctFilledIn
    //Returns a HashSet -- how can you use this?  What should this HashSet be used for?
    //trace the countDistinctFilledIn functions!
    private static HashSet<Board> distinctFilledInHelper(Board b){
        //Hint: look at the HashSet API, there's some method(s) that will come in handy... add___( )
        HashSet<Board> unique = new HashSet<Board>();
        int rows = b.size();
        if(b.isFull())
        	unique.add(b.copy());
        Board.Mark current = b.nextPlayer();
        for (int row = 0; row < rows; row++){
        	for (int col = 0; col < rows; col++){
        		if (b.isOpen(row, col)){
        			Board temp = b.copy();
        			temp.placeMark(row, col, current);
        			unique.addAll(distinctFilledInHelper(temp));  
        		}
        	}
        }  
        return unique;
    }
                                                         


    /**
     * DLN 9.102
     * @return number of boards in game tree (when you play til board is completely filled in)
     */
    public static int countBoardsInTree() {
        return countBoardsInTree(new Board());
    }

    /**
     * Variation on DLN 9.102
     * @param b current board
     * @return number of all boards (not just leaves) in game subtree whose root is board b
     */
    public static int countBoardsInTree(Board b) {
        if(b.isFull())
        	return 1;
        int rows = b.size();
        int boards_total = 0;
        Board.Mark current = b.nextPlayer();
        for (int row = 0; row < rows; row++){
        	for (int col = 0; col < rows; col++){
        		if (b.isOpen(row, col)){
        			Board temp = b.copy();
        			temp.placeMark(row, col, current);
        			boards_total += countBoardsInTree(temp); 
        		}
        	}
        }
        return boards_total+1;
    }


    /**
     * DLN 9.103
     * @return number of all unique boards (not just leaves) in game tree (when you play til board is completely filled in)
     */
    public static int countDistinctBoardsInTree() {
        return countDistinctBoardsInTree(new Board());
    }

    /**
     * Variation on DLN 9.103
     * @param b current board
     * @return number of all unique boards (not just leaves) in game subtree whose root is board b
     */
    public static int countDistinctBoardsInTree(Board b) {
    	return distinctBoardHelper(b).size();
    }
    
    private static HashSet<Board> distinctBoardHelper(Board b) {
    	HashSet<Board> unique = new HashSet<Board>();
    	int rows = b.size();
        if(b.isFull())
        	unique.add(b.copy());
        Board.Mark current = b.nextPlayer();
        for (int row = 0; row < rows; row++){
        	for (int col = 0; col < rows; col++){
        		if (b.isOpen(row, col)){
        			Board temp = b.copy();
        			temp.placeMark(row, col, current);
        			unique.add(temp);
        			unique.addAll(distinctBoardHelper(temp));  
        		}
        	}
        }
        unique.add(b.copy());
        return unique;
    }
        

    /**
     * DLN 9.104
     * @return number of all unique boards (not just leaves), accounting for symmetry, (when you play til board is 
     * completely filled in)
     * playing when the game is won
     */
    public static int countWithSymmetry() {
        return countWithSymmetry(new Board());
    }

    /**
     * Variation on DLN 9.104
     * @param b current board
     * @return number of all unique boards (not just leaves), accounting for symmetry, in game subtree whose root is 
     * board b, (when you play til board is completely filled in)
     */
    public static int countWithSymmetry(Board b) {
    	HashSet<Board> symmetry_repeats = countWithSymmetryHelper(b);
    	HashSet<Board> tree_unique = new HashSet<Board>();
    	for(Board temp : symmetry_repeats) {
    		if(flip_check(temp, tree_unique))
    			tree_unique.add(temp);
    	}
        return tree_unique.size();
    }
    
   private static HashSet<Board> countWithSymmetryHelper(Board b) {
    	HashSet<Board> unique = new HashSet<Board>();
    	int rows = b.size();
        if(b.isFull())
        	unique.add(b.copy());
        Board.Mark current = b.nextPlayer();
        for (int row = 0; row < rows; row++){
        	for (int col = 0; col < rows; col++){
        		if (b.isOpen(row, col)){
        			Board temp = b.copy();
        			temp.placeMark(row, col, current);
        			if(flip_check(temp, unique)){
        				unique.add(temp); 
        				unique.addAll(countWithSymmetryHelper(temp));
        			}
        		}
        	}
        }
        unique.add(b.copy());
        return unique;
    }
    
    // true is no symmetries exist in hashset
    private static boolean flip_check(Board b, HashSet<Board> unique) {
    	Board temp = b.copy();
    	Board flip_temp = temp.flip();
    	if (unique.contains(temp.rotate()) || unique.contains(temp.rotate().rotate()) || unique.contains(temp.rotate().rotate().rotate())) 
    		return false;
    	else if (unique.contains(flip_temp) || unique.contains(flip_temp.rotate()) || unique.contains(flip_temp.rotate().rotate()) || unique.contains(flip_temp.rotate().rotate().rotate()))
    		return false;
    	return true;
    }


    /**
     * DLN 9.105
     * @return number of all unique boards (not just leaves), accounting for symmetry, in game subtree whose root is 
     * board b, and you STOP playing when the game is won
     */
    public static int countWithSymmetryWins() {
        return countWithSymmetryWins(new Board());
    }

    /**
     * Variation on DLN 9.105
     * @param b current board
     * @return number of number of unique boards, accounting for symmetry and wins, in game subtree whose root is 
     * board b, and you STOP playing when the game is won
     */
    public static int countWithSymmetryWins(Board b) {
        HashSet<Board> symmetry_repeats = withSymmetryWinsHelper(b);
    	HashSet<Board> tree_unique = new HashSet<Board>();
    	
    	for(Board temp : symmetry_repeats) {
    		if(flip_check(temp, tree_unique))
    			tree_unique.add(temp);
    	}
    	
        return tree_unique.size();
    }
    
    private static HashSet<Board> withSymmetryWinsHelper(Board b) {
    	HashSet<Board> unique = new HashSet<Board>();
    	int rows = b.size();
        if(b.hasWinner()) {
        	unique.add(b.copy());
        	return unique;
        }
        Board.Mark current = b.nextPlayer();
        for (int row = 0; row < rows; row++){
        	for (int col = 0; col < rows; col++){
        		if (b.isOpen(row, col)){
        			Board temp = b.copy();
        			temp.placeMark(row, col, current);
        			if(flip_check(temp, unique)){
        				unique.add(temp); 
        				unique.addAll(withSymmetryWinsHelper(temp));
        			}
        		}
        	}
        }
        if(!(b.hasWinner()) && !(isEmpty(b.copy())))
        	return unique;
        unique.add(b.copy()); //add the root to the board if its empty
        return unique;
    }
    
    private static boolean isEmpty(Board b) {
    	int rows = b.size();
    	for (int row = 0; row < rows; row++){
        	for (int col = 0; col < rows; col++){
        		if(!(b.isOpen(row, col)))
        			return false;
        	}
		}
		return true;
    }
    
    
    public static void main(String[] args) {
      //Should match your answer to question 2.4!
      System.out.println("Problem 9.100: count of (non-unique) completed boards: " + countFilledIn());    
      
      //Should be 126 given an empty board as root
      System.out.println("Problem 9.101: count of unique completed boards: " + countDistinctFilledIn());  
      
      //Should be 986410 given an empty board as root
      System.out.println("Problem 9.102: count of all boards: " + countBoardsInTree());
      
      //Should be 6046 given an empty board as root
      System.out.println("Problem 9.103: count of all unique boards: " + countDistinctBoardsInTree());
      
      //Should be 850 given an empty board as root
      System.out.println("Problem 9.104: count of all unique symmetrical boards: " + countWithSymmetry());
      
      //Should be 765 given an empty board as root
      System.out.println("Problem 9.105: count of all unique symmetrical boards (stopping at wins): " + countWithSymmetryWins());
      
      // Add tests of your own!
      Board b1 = new Board("X  |   |   ");
      System.out.println("TESTS WITH ONE SPOT FILLED");
      System.out.println("Problem 9.100: count of (non-unique) completed boards: " + countFilledIn(b1)); 
      System.out.println("Problem 9.101: count of unique completed boards: " + countDistinctFilledIn(b1));
      System.out.println("Problem 9.102: count of all boards: " + countBoardsInTree(b1));
      System.out.println("Problem 9.103: count of all unique boards: " + countDistinctBoardsInTree(b1));
      System.out.println("Problem 9.104: count of all unique symmetrical boards: " + countWithSymmetry(b1));
      System.out.println("Problem 9.105: count of all unique symmetrical boards (stopping at wins): " + countWithSymmetryWins(b1));
      
      Board b2 = new Board("XXO|OXX|OOX");
      System.out.println("TESTS WITH FULL BOARD WITH WINNER");
      System.out.println("Problem 9.100: count of (non-unique) completed boards: " + countFilledIn(b2)); 
      System.out.println("Problem 9.101: count of unique completed boards: " + countDistinctFilledIn(b2));
      System.out.println("Problem 9.102: count of all boards: " + countBoardsInTree(b2));
      System.out.println("Problem 9.103: count of all unique boards: " + countDistinctBoardsInTree(b2));
      System.out.println("Problem 9.104: count of all unique symmetrical boards: " + countWithSymmetry(b2));
      System.out.println("Problem 9.105: count of all unique symmetrical boards (stopping at wins): " + countWithSymmetryWins(b2));
      
      Board b3 = new Board("OOX|XXO|OXX");
      System.out.println("TESTS WITH FULL BOARD WITHOUT WINNER");
      System.out.println("Problem 9.100: count of (non-unique) completed boards: " + countFilledIn(b3)); 
      System.out.println("Problem 9.101: count of unique completed boards: " + countDistinctFilledIn(b3));
      System.out.println("Problem 9.102: count of all boards: " + countBoardsInTree(b3));
      System.out.println("Problem 9.103: count of all unique boards: " + countDistinctBoardsInTree(b3));
      System.out.println("Problem 9.104: count of all unique symmetrical boards: " + countWithSymmetry(b3));
      System.out.println("Problem 9.105: count of all unique symmetrical boards (stopping at wins): " + countWithSymmetryWins(b3));
    }
  
}
